"""
masscan_runner.py — Wraps the masscan binary, parses JSON output.
Supports both TCP (Java 25565) and UDP (Bedrock 19132) port scanning.

Returns list of (ip, port, proto) tuples.
"""

import json
import logging
import os
import re
import subprocess
import tempfile

log = logging.getLogger("masscan")


class MasscanRunner:
    def __init__(
        self,
        binary: str = "masscan",
        rate: int = 10000,
        ports: str = "25565,U:19132",
        ranges: list[str] | None = None,
        exclude_file: str = "",
        retries: int = 2,
        timeout: int = 600,
        interface: str = "eth0",
    ):
        self.binary = binary
        self.rate = rate
        self.ports = ports
        self.ranges = ranges or []
        self.exclude_file = exclude_file
        self.retries = retries
        self.timeout = timeout
        self.interface = interface

    def scan(self) -> list[tuple[str, int, str]]:
        """Run masscan and return (ip, port, proto) tuples."""
        if not self.ranges:
            log.warning("No scan ranges configured — nothing to scan.")
            return []

        targets_file = tempfile.NamedTemporaryFile(
            mode="w", suffix=".txt", delete=False, prefix="masscan_targets_"
        )
        for r in self.ranges:
            targets_file.write(r + "\n")
        targets_file.close()

        out_file = tempfile.NamedTemporaryFile(
            suffix=".json", delete=False, prefix="masscan_out_"
        )
        out_file.close()

        cmd = [
            self.binary,
            "-iL", targets_file.name,
            "-p", self.ports,
            "--rate", str(self.rate),
            "-oJ", out_file.name,
            "--retries", str(self.retries),
            "-e", self.interface,
            "--insecure",
        ]
        if self.exclude_file:
            cmd += ["--excludefile", self.exclude_file]

        log.info("Starting masscan: %s", " ".join(cmd))

        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=self.timeout)
            if proc.returncode != 0:
                log.error("masscan exited %d: %s", proc.returncode, proc.stderr[:500])
        except subprocess.TimeoutExpired:
            log.error("masscan timed out after %ds", self.timeout)
        except FileNotFoundError:
            log.error("masscan binary not found at '%s'. Install it first.", self.binary)
            return []
        finally:
            os.unlink(targets_file.name)

        servers = self._parse_output(out_file.name)
        try:
            os.unlink(out_file.name)
        except OSError:
            pass

        log.info("masscan found %d open Minecraft ports", len(servers))
        return servers

    def _parse_output(self, path: str) -> list[tuple[str, int, str]]:
        """Parse masscan -oJ output into (ip, port, proto) tuples."""
        results = []
        try:
            with open(path, "r") as f:
                raw = f.read().strip()
        except FileNotFoundError:
            return []

        if not raw:
            return []

        raw = re.sub(r",\s*]", "]", raw)
        raw = re.sub(r",\s*}", "}", raw)

        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            for line in raw.splitlines():
                line = line.strip().rstrip(",")
                if not line or line in ("[", "]"):
                    continue
                try:
                    obj = json.loads(line)
                    self._extract(obj, results)
                except json.JSONDecodeError:
                    continue
            return results

        if isinstance(data, list):
            for obj in data:
                self._extract(obj, results)
        elif isinstance(data, dict):
            self._extract(data, results)

        return results

    @staticmethod
    def _extract(obj: dict, results: list):
        ip = obj.get("ip")
        if not ip:
            return
        for p in obj.get("ports", []):
            port_num = p.get("port")
            proto = p.get("proto", "tcp")
            if port_num:
                results.append((ip, int(port_num), proto))


if __name__ == "__main__":
    runner = MasscanRunner(
        rate=1000,
        ports="25565,U:19132",
        ranges=["127.0.0.1/32"],
    )
    found = runner.scan()
    print(f"Found: {found}")