"""
query_protocol.py — GameSpy4 / UT3 query protocol for Minecraft servers.

Gets FULL server info including player names and plugin list.
Works for both Java (UDP query) and Bedrock (UDP query) servers.

Java servers require `enable-query=true` in server.properties.
Bedrock servers typically have query enabled by default.

The query response includes a `plugins` field that lists installed plugins —
this is the primary source for the Plugin Checker.
"""

import asyncio
import struct
import logging

log = logging.getLogger("query")

MAGIC = b"\xfe\xfd"


class _QueryProtocol(asyncio.DatagramProtocol):
    """Simple datagram protocol that queues received packets."""

    def __init__(self):
        self.responses: asyncio.Queue = asyncio.Queue()

    def connection_made(self, transport):
        self.transport = transport

    def datagram_received(self, data, addr):
        try:
            self.responses.put_nowait(data)
        except Exception:
            pass

    def error_received(self, exc):
        try:
            self.responses.put_nowait(exc)
        except Exception:
            pass


async def query_server(host: str, port: int, timeout: float = 5.0) -> dict | None:
    """
    Query a Minecraft server via GameSpy4 protocol (UDP).
    Returns dict with: motd, plugins, players, numplayers, maxplayers, version, map, gametype
    or None if query is not available / timed out.
    """
    loop = asyncio.get_running_loop()
    session_id = 0x01020304

    try:
        transport, protocol = await loop.create_datagram_endpoint(
            lambda: _QueryProtocol(),
            remote_addr=(host, port),
        )
    except OSError:
        return None

    try:
        # ── Phase 1: Handshake (get challenge token) ───────────────────
        handshake = MAGIC + b"\x09" + struct.pack(">I", session_id)
        transport.sendto(handshake)

        resp = await asyncio.wait_for(protocol.responses.get(), timeout)
        if len(resp) < 6:
            return None

        # Response: type(1) + session_id(4) + challenge_string + \x00
        challenge_str = resp[5:].split(b"\x00")[0].decode("ascii", errors="replace")
        try:
            challenge_token = int(challenge_str)
        except ValueError:
            return None

        # ── Phase 2: Full stat request ─────────────────────────────────
        stat_req = (
            MAGIC + b"\x00"                          # type = STAT
            + struct.pack(">I", session_id)          # session ID
            + struct.pack(">I", challenge_token & 0xFFFFFFFF)  # challenge
            + b"\x00\x00\x00\x00"                    # padding
        )
        transport.sendto(stat_req)

        resp = await asyncio.wait_for(protocol.responses.get(), timeout)
        return _parse_stat_response(resp)

    except (asyncio.TimeoutError, OSError, ValueError, UnicodeDecodeError, IndexError):
        return None
    finally:
        transport.close()


def _parse_stat_response(data: bytes) -> dict | None:
    """Parse a full stat response from the query protocol."""
    if len(data) < 5:
        return None

    offset = 5  # skip type(1) + session_id(4)

    # Look for "splitnum\x00" — marks the start of full stat
    splitnum = b"splitnum\x00"
    idx = data.find(splitnum, offset)
    if idx == -1:
        return _parse_basic_stat(data, offset)

    offset = idx + len(splitnum)

    # Skip padding bytes (typically \x00\x80 or \x00\x00)
    while offset < len(data) and data[offset] in (0x00, 0x80):
        offset += 1

    # ── Parse key-value pairs ────────────────────────────────────────
    fields = {}
    while offset < len(data):
        key_end = data.find(b"\x00", offset)
        if key_end == -1:
            break
        key = data[offset:key_end].decode("utf-8", errors="replace")
        offset = key_end + 1

        if not key:
            break  # empty key = end of KV section

        val_end = data.find(b"\x00", offset)
        if val_end == -1:
            break
        value = data[offset:val_end].decode("utf-8", errors="replace")
        offset = val_end + 1

        fields[key] = value

    # ── Parse player section ─────────────────────────────────────────
    players = []
    player_marker = b"player_\x00"
    idx = data.find(player_marker, offset)
    if idx != -1:
        offset = idx + len(player_marker)
        # Skip padding
        while offset < len(data) and data[offset] in (0x00, 0x01):
            offset += 1

        while offset < len(data):
            name_end = data.find(b"\x00", offset)
            if name_end == -1:
                name = data[offset:].decode("utf-8", errors="replace")
                if name.strip():
                    players.append(name.strip())
                break
            name = data[offset:name_end].decode("utf-8", errors="replace")
            offset = name_end + 1
            if name.strip():
                players.append(name.strip())

    return {
        "motd": fields.get("hostname", fields.get("motd", "")),
        "plugins": fields.get("plugins", ""),
        "version": fields.get("version", ""),
        "numplayers": fields.get("numplayers", "0"),
        "maxplayers": fields.get("maxplayers", "0"),
        "gametype": fields.get("gametype", ""),
        "map": fields.get("map", fields.get("level_name", "")),
        "hostip": fields.get("hostip", ""),
        "hostport": fields.get("hostport", ""),
        "players": players,
    }


def _parse_basic_stat(data: bytes, offset: int) -> dict | None:
    """Parse a basic stat response (no player list)."""
    fields = {}
    while offset < len(data):
        key_end = data.find(b"\x00", offset)
        if key_end == -1:
            break
        key = data[offset:key_end].decode("utf-8", errors="replace")
        offset = key_end + 1
        if not key:
            break
        val_end = data.find(b"\x00", offset)
        if val_end == -1:
            break
        value = data[offset:val_end].decode("utf-8", errors="replace")
        offset = val_end + 1
        fields[key] = value

    return {
        "motd": fields.get("hostname", ""),
        "plugins": fields.get("plugins", ""),
        "version": fields.get("version", ""),
        "numplayers": fields.get("numplayers", "0"),
        "maxplayers": fields.get("maxplayers", "0"),
        "gametype": fields.get("gametype", ""),
        "map": fields.get("map", ""),
        "players": [],
    }


async def query_many(
    servers: list[tuple[str, int]],
    timeout: float = 5.0,
    concurrency: int = 200,
) -> list[tuple[tuple[str, int], dict]]:
    """
    Query many servers concurrently.
    Returns list of ((host, port), result_dict) for successful queries.
    """
    sem = asyncio.Semaphore(concurrency)

    async def _wrapped(h, p):
        async with sem:
            return (h, p), await query_server(h, p, timeout)

    tasks = [_wrapped(h, p) for h, p in servers]
    results = await asyncio.gather(*tasks, return_exceptions=True)
    return [
        (key, r) for (key, r) in results
        if isinstance(r, dict)
    ]


# ─── self-test ────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys, json
    h = sys.argv[1] if len(sys.argv) > 1 else "play.hypixel.net"
    p = int(sys.argv[2]) if len(sys.argv) > 2 else 25565
    r = asyncio.run(query_server(h, p, timeout=10))
    print(json.dumps(r, indent=2) if r else f"Query not available on {h}:{p}")