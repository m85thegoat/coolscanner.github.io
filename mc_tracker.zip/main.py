"""
main.py — Entry point for the Minecraft Bot Tracker (UUID-based).

Wires together:
  - TelegramBot   (command interface + notifier)
  - Tracker        (masscan → ping → match loop, UUID matching)

Run:
    sudo python main.py

Requires:
    - masscan installed and accessible (run as root for raw sockets)
    - Telegram bot token set in config.py
    - pip install -r requirements.txt
"""

import asyncio
import logging
import signal
import sys

from config import LOG_FILE, LOG_LEVEL, SCAN_INTERVAL_MIN, TARGETS, MASSCAN_ENABLED
from telegram_bot import TelegramBot
from tracker import Tracker


def setup_logging():
    fmt = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
    handlers = [
        logging.StreamHandler(sys.stdout),
    ]
    if LOG_FILE:
        handlers.append(logging.FileHandler(LOG_FILE))
    logging.basicConfig(
        level=getattr(logging, LOG_LEVEL, logging.INFO),
        format=fmt,
        handlers=handlers,
    )


async def main():
    setup_logging()
    log = logging.getLogger("main")

    log.info("=== Minecraft Bot Tracker (UUID-based) starting ===")
    log.info("Pre-seeded targets: %d", len(TARGETS))
    log.info("Masscan: %s", "ON" if MASSCAN_ENABLED else "OFF")
    log.info("Scan interval: %d min", SCAN_INTERVAL_MIN)

    # Build Telegram bot
    tg_bot = TelegramBot()

    # Build tracker (notifier wired after bot starts)
    tracker = Tracker(notifier=None)

    # Link them
    tg_bot.set_tracker(tracker)

    # Start Telegram polling
    try:
        await tg_bot.start_polling()
    except ValueError as e:
        log.error("%s", e)
        log.error("Get a token from @BotFather, then edit config.py.")
        return
    except Exception as e:
        log.error("Failed to start Telegram bot: %s", e)
        return

    # Wire notifier now that bot is up
    tracker.notifier = tg_bot.notifier

    # Graceful shutdown
    stop_event = asyncio.Event()

    def _signal_handler(sig, frame):
        log.info("Received signal %d, shutting down...", sig)
        stop_event.set()

    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, stop_event.set)
        except NotImplementedError:
            pass

    # Run tracker loop as a background task
    tracker_task = asyncio.create_task(tracker.run_forever())

    # Wait for shutdown signal
    await stop_event.wait()

    log.info("Shutting down...")
    tracker_task.cancel()
    try:
        await tracker_task
    except asyncio.CancelledError:
        pass

    await tg_bot.stop()
    log.info("Goodbye!")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nStopped.")