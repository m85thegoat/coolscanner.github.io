"""
tracker.py — Core tracking engine (UUID-based, multi-protocol).

Pipeline per cycle:
  1. Discover servers  → masscan (TCP 25565 + UDP 19132) or manual list
  2. Ping servers      → Java SLP (TCP) + Bedrock RakNet (UDP)
  3. Query servers     → GameSpy4 query for player names + plugins
  4. Match targets     → compare player UUIDs/names against watch list
  5. Plugin check      → detect server software + plugins
  6. Notify            → Telegram alert on hit
  7. Log summary       → "333 SCANNED | 9 CONNECTABLE | NO TARGET FOUNDED"
"""

import asyncio
import logging
import time
from dataclasses import dataclass, field

from config import (
    TARGETS,
    MASSCAN_BINARY, MASSCAN_RATE, MASSCAN_PORTS, SCAN_RANGES,
    MASSCAN_EXCLUDE_FILE, MASSCAN_RETRIES, MASSCAN_ENABLED,
    MANUAL_SERVERS,
    JAVA_PORTS, BEDROCK_PORTS,
    PING_TIMEOUT, PING_CONCURRENCY, PING_PROTOCOLS,
    BEDROCK_PING_TIMEOUT, BEDROCK_PING_CONCURRENCY,
    QUERY_ENABLED, QUERY_TIMEOUT, QUERY_CONCURRENCY,
    SCAN_INTERVAL_MIN, SEEN_CACHE_TTL_SEC,
    PLUGIN_CHECK_ENABLED,
)
from masscan_runner import MasscanRunner
from mc_pinger import ping_many
from bedrock_pinger import ping_bedrock_many
from query_protocol import query_server
from plugin_checker import check_plugins, format_plugin_report

log = logging.getLogger("tracker")


def normalize_uuid(uuid_str: str) -> str:
    return uuid_str.replace("-", "").strip().lower()


@dataclass
class Hit:
    username: str
    uuid: str
    host: str
    port: int
    proto: str
    motd: str
    players_online: int
    players_max: int
    version: str
    ping_ms: int
    plugin_report: dict | None = None
    timestamp: float = field(default_factory=time.time)

    def telegram_text(self) -> str:
        uuid_fmt = self.uuid
        if len(uuid_fmt) == 32:
            uuid_fmt = f"{uuid_fmt[:8]}-{uuid_fmt[8:12]}-{uuid_fmt[12:16]}-{uuid_fmt[16:20]}-{uuid_fmt[20:]}"
        proto_label = "🟫 Bedrock" if self.proto == "udp" else "🟩 Java"
        text = (
            f"🎯 **TARGET FOUND!**\n"
            f"👤 Player: `{self.username}`\n"
            f"🆔 UUID: `{uuid_fmt}`\n"
            f"{proto_label} Server: `{self.host}:{self.port}`\n"
            f"📝 MOTD: {self.motd[:80]}\n"
            f"👥 Online: {self.players_online}/{self.players_max}\n"
            f"🎮 Version: {self.version}\n"
            f"⏱ Ping: {self.ping_ms}ms\n"
            f"🕐 Time: {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(self.timestamp))}"
        )
        if self.plugin_report:
            text += f"\n\n{format_plugin_report(self.plugin_report)}"
        return text


class Tracker:
    def __init__(self, notifier=None):
        self.notifier = notifier
        self.targets = [dict(t) for t in TARGETS]
        self._target_uuids: set[str] = set()
        self._rebuild_uuid_index()

        self.masscan_enabled = MASSCAN_ENABLED
        self.seen: dict[str, float] = {}

        self.scanner = MasscanRunner(
            binary=MASSCAN_BINARY,
            rate=MASSCAN_RATE,
            ports=MASSCAN_PORTS,
            ranges=SCAN_RANGES,
            exclude_file=MASSCAN_EXCLUDE_FILE,
            retries=MASSCAN_RETRIES,
        )

        # Stats
        self.last_scan_time = None
        self.last_scanned = 0
        self.last_connectable = 0
        self.last_hits: list[Hit] = []
        self.last_plugin_reports: dict[str, dict] = {}  # key = "host:port" → report
        self.total_hits = 0
        self.total_scans = 0

    # ─── Target management ────────────────────────────────────────────────

    def _rebuild_uuid_index(self):
        self._target_uuids = {normalize_uuid(t["uuid"]) for t in self.targets if t.get("uuid")}

    def add_target(self, username: str, uuid: str) -> bool:
        norm = normalize_uuid(uuid)
        for t in self.targets:
            if normalize_uuid(t.get("uuid", "")) == norm:
                return False
        self.targets.append({"username": username, "uuid": uuid})
        self._rebuild_uuid_index()
        log.info("Added target: %s (UUID: %s)", username, uuid)
        return True

    def remove_target(self, username: str) -> bool:
        before = len(self.targets)
        self.targets = [t for t in self.targets if t["username"].lower() != username.lower()]
        self._rebuild_uuid_index()
        removed = len(self.targets) < before
        if removed:
            log.info("Removed target: %s", username)
        return removed

    def get_targets(self) -> list[dict]:
        return list(self.targets)

    # ─── Masscan toggle ───────────────────────────────────────────────────

    def set_masscan(self, enabled: bool):
        self.masscan_enabled = enabled
        state = "ON" if enabled else "OFF"
        log.info("Masscan toggled %s", state)
        return state

    # ─── Seen cache ───────────────────────────────────────────────────────

    def _is_seen_recently(self, key: str) -> bool:
        now = time.time()
        if key in self.seen and now - self.seen[key] < SEEN_CACHE_TTL_SEC:
            return True
        self.seen = {k: v for k, v in self.seen.items() if now - v < SEEN_CACHE_TTL_SEC}
        return False

    def _mark_seen(self, key: str):
        self.seen[key] = time.time()

    # ─── Server normalization ─────────────────────────────────────────────

    @staticmethod
    def _normalize_server(server) -> tuple[str, int, str]:
        """Normalize to (host, port, proto). Auto-detect proto from port."""
        if len(server) == 2:
            host, port = server
            proto = "udp" if port in BEDROCK_PORTS else "tcp"
            return (host, port, proto)
        elif len(server) == 3:
            return server
        else:
            raise ValueError(f"Invalid server tuple: {server}")

    # ─── Scan cycle ───────────────────────────────────────────────────────

    async def run_cycle(self) -> list[Hit]:
        """Run one full scan → ping → query → match → notify cycle."""
        self.total_scans += 1
        cycle_num = self.total_scans
        log.info("═══════ SCAN CYCLE #%d ═══════", cycle_num)

        # 1. Discover servers
        if self.masscan_enabled:
            log.info("📡 Masscan: ON — scanning IP ranges for %s...", MASSCAN_PORTS)
            raw_servers = self.scanner.scan()
        else:
            log.info("📡 Masscan: OFF — using manual server list (%d servers)", len(MANUAL_SERVERS))
            raw_servers = list(MANUAL_SERVERS)

        servers = [self._normalize_server(s) for s in raw_servers]
        scanned_count = len(servers)

        if not servers:
            log.info("│ %d SCANNED | 0 CONNECTABLE | NO TARGET FOUNDED", scanned_count)
            self._update_stats(scanned_count, 0, [])
            return []

        # 2. Route to correct pinger by protocol
        java_servers = [(h, p) for h, p, proto in servers if proto == "tcp" or p in JAVA_PORTS]
        bedrock_servers = [(h, p) for h, p, proto in servers if proto == "udp" or p in BEDROCK_PORTS]

        log.info("│ Pinging %d Java + %d Bedrock servers...", len(java_servers), len(bedrock_servers))

        # 3. Ping all servers concurrently
        java_task = ping_many(java_servers, timeout=PING_TIMEOUT,
                              concurrency=PING_CONCURRENCY, protocols=PING_PROTOCOLS)
        bedrock_task = ping_bedrock_many(bedrock_servers, timeout=BEDROCK_PING_TIMEOUT,
                                         concurrency=BEDROCK_PING_CONCURRENCY)

        java_results, bedrock_results = await asyncio.gather(java_task, bedrock_task)

        # Tag results with proto
        for r in java_results:
            r["proto"] = "tcp"
        for r in bedrock_results:
            r["proto"] = "udp"

        all_results = java_results + bedrock_results
        connectable_count = len(all_results)

        log.info("│ Java: %d/%d reachable | Bedrock: %d/%d reachable",
                 len(java_results), len(java_servers),
                 len(bedrock_results), len(bedrock_servers))

        # 4. Query protocol — get player names + plugins for connectable servers
        query_results: dict[str, dict] = {}  # key = "host:port" → query data
        if QUERY_ENABLED and all_results:
            log.info("│ Running GameSpy4 query on %d servers for player names + plugins...",
                     len(all_results))

            sem = asyncio.Semaphore(QUERY_CONCURRENCY)

            async def _query(host, port):
                async with sem:
                    # Try same port first, then port+1
                    result = await query_server(host, port, QUERY_TIMEOUT)
                    if result is None:
                        result = await query_server(host, port + 1, QUERY_TIMEOUT)
                    return (f"{host}:{port}", result)

            query_tasks = [_query(r["host"], r["port"]) for r in all_results]
            query_raw = await asyncio.gather(*query_tasks, return_exceptions=True)

            for item in query_raw:
                if isinstance(item, tuple) and isinstance(item[1], dict):
                    query_results[item[0]] = item[1]

            log.info("│ Query successful on %d/%d servers", len(query_results), len(all_results))

        # 5. Merge query player names into SLP results
        for srv in all_results:
            key = f"{srv['host']}:{srv['port']}"
            qdata = query_results.get(key)
            if qdata:
                # If SLP player sample is empty, use query player list
                if not srv.get("players") and qdata.get("players"):
                    srv["players"] = [
                        {"name": name, "uuid": ""}
                        for name in qdata["players"]
                    ]
                srv["query_data"] = qdata
            else:
                srv["query_data"] = None

        # 6. Plugin check on connectable servers
        plugin_reports: dict[str, dict] = {}
        if PLUGIN_CHECK_ENABLED:
            for srv in all_results:
                key = f"{srv['host']}:{srv['port']}"
                report = check_plugins(slp_data=srv, query_data=srv.get("query_data"))
                plugin_reports[key] = report
            self.last_plugin_reports = plugin_reports

        # 7. Check for targets
        hits = []
        for srv in all_results:
            for player in srv.get("players", []):
                player_name = player.get("name", "") if isinstance(player, dict) else player
                player_uuid = ""
                if isinstance(player, dict):
                    player_uuid = normalize_uuid(player.get("uuid", ""))

                matched = False
                target_name = player_name

                # UUID match (preferred)
                if player_uuid and player_uuid in self._target_uuids:
                    matched = True
                    for t in self.targets:
                        if normalize_uuid(t["uuid"]) == player_uuid:
                            target_name = t["username"]
                            break
                else:
                    # Name match fallback
                    for t in self.targets:
                        if t["username"].lower() == player_name.lower():
                            matched = True
                            target_name = t["username"]
                            player_uuid = normalize_uuid(t["uuid"])
                            break

                if matched:
                    key = f"{player_uuid or player_name.lower()}@{srv['host']}:{srv['port']}"
                    if self._is_seen_recently(key):
                        log.debug("│ Skipping (recently seen): %s", key)
                        continue

                    srv_key = f"{srv['host']}:{srv['port']}"
                    hit = Hit(
                        username=target_name,
                        uuid=player_uuid or "",
                        host=srv["host"],
                        port=srv["port"],
                        proto=srv.get("proto", "tcp"),
                        motd=srv.get("motd", ""),
                        players_online=srv.get("players_online", 0),
                        players_max=srv.get("players_max", 0),
                        version=srv.get("version", "unknown"),
                        ping_ms=srv.get("ping_ms", 0),
                        plugin_report=plugin_reports.get(srv_key),
                    )
                    hits.append(hit)
                    self._mark_seen(key)
                    log.info("│ 🎯 HIT: %s on %s:%d (%s)", target_name, srv["host"], srv["port"], srv.get("proto"))

        # 8. Notify
        if hits and self.notifier:
            for hit in hits:
                try:
                    await self.notifier.notify(hit)
                except Exception as e:
                    log.error("│ Notify failed for %s: %s", hit.username, e)

        # 9. Log summary
        target_str = f"{len(hits)} TARGET{'S' if len(hits) != 1 else ''} FOUND" if hits else "NO TARGET FOUNDED"
        summary = f"{scanned_count} SCANNED | {connectable_count} CONNECTABLE | {target_str}"
        masscan_str = "ON" if self.masscan_enabled else "OFF"
        log.info("┃ %s | masscan: %s", summary, masscan_str)
        log.info("═══════ CYCLE #%d COMPLETE ═══════", cycle_num)

        # 10. Update stats
        self._update_stats(scanned_count, connectable_count, hits)

        # 11. Send summary to Telegram
        if self.notifier:
            try:
                await self.notifier.notify_summary(summary, masscan_str, cycle_num)
            except Exception:
                pass

        return hits

    def _update_stats(self, scanned: int, connectable: int, hits: list[Hit]):
        self.last_scan_time = time.time()
        self.last_scanned = scanned
        self.last_connectable = connectable
        self.last_hits = hits
        self.total_hits += len(hits)

    async def run_forever(self):
        target_names = [t["username"] for t in self.targets]
        log.info("Tracker started. Watching %d target(s): %s", len(target_names), target_names)
        log.info("Masscan: %s | Ports: %s", "ON" if self.masscan_enabled else "OFF", MASSCAN_PORTS)
        log.info("Query: %s | Plugin check: %s",
                 "ON" if QUERY_ENABLED else "OFF",
                 "ON" if PLUGIN_CHECK_ENABLED else "OFF")
        while True:
            try:
                await self.run_cycle()
            except Exception as e:
                log.error("Cycle error: %s", e, exc_info=True)
            wait_sec = SCAN_INTERVAL_MIN * 60
            log.info("Sleeping %d minutes until next cycle...", SCAN_INTERVAL_MIN)
            await asyncio.sleep(wait_sec)