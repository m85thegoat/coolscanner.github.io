"""
telegram_bot.py — Telegram bot for the Minecraft tracker (UUID, multi-protocol).

Commands:
  /start              — show help
  /status             — tracker status (targets, masscan, last scan summary)
  /target <USERNAME>  — track a player (fetches UUID from Mojang)
  /untarget <USERNAME>— stop tracking a player
  /targets            — list watched players + UUIDs
  /masscan <on|off>   — toggle masscan scanning
  /scan               — trigger immediate scan cycle
  /servers            — list connectable servers from last scan
  /plugins <host> [p] — check plugins on a specific server
  /help               — full help
"""

import asyncio
import logging
import time

import aiohttp
from telegram import Update
from telegram.constants import ParseMode
from telegram.ext import (
    Application,
    ApplicationBuilder,
    CommandHandler,
    ContextTypes,
)

from config import (
    TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID,
    MOJANG_API_URL, MOJANG_TIMEOUT,
    JAVA_PORTS, BEDROCK_PORTS,
)
from mc_pinger import ping_server
from bedrock_pinger import ping_bedrock
from query_protocol import query_server
from plugin_checker import check_plugins, format_plugin_report

log = logging.getLogger("telegram_bot")


# ─── Mojang UUID lookup ──────────────────────────────────────────────────────

async def fetch_uuid(username: str, timeout: int = MOJANG_TIMEOUT) -> dict | None:
    url = MOJANG_API_URL.format(username=username)
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=timeout)) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    return {"username": data.get("name", username), "uuid": data.get("id", "")}
                return None
    except (aiohttp.ClientError, asyncio.TimeoutError) as e:
        log.error("Mojang API error for '%s': %s", username, e)
        return None


# ─── Notifier ────────────────────────────────────────────────────────────────

class TelegramNotifier:
    def __init__(self, bot_app: Application):
        self.bot_app = bot_app
        self.chat_id = TELEGRAM_CHAT_ID

    async def notify(self, hit):
        try:
            await self.bot_app.bot.send_message(
                chat_id=self.chat_id, text=hit.telegram_text(),
                parse_mode=ParseMode.MARKDOWN,
            )
            log.info("Sent alert for %s on %s:%d", hit.username, hit.host, hit.port)
        except Exception as e:
            log.error("Telegram send failed: %s", e)

    async def notify_summary(self, summary: str, masscan_str: str, cycle_num: int):
        """Send a scan cycle summary to the chat."""
        text = f"📊 **Scan #{cycle_num}**\n`{summary}`\n📡 Masscan: {masscan_str}"
        try:
            await self.bot_app.bot.send_message(
                chat_id=self.chat_id, text=text,
                parse_mode=ParseMode.MARKDOWN,
            )
        except Exception:
            pass


# ─── Bot ─────────────────────────────────────────────────────────────────────

class TelegramBot:
    def __init__(self, tracker=None):
        self.tracker = tracker
        self.app: Application | None = None
        self.notifier: TelegramNotifier | None = None

    def set_tracker(self, tracker):
        self.tracker = tracker

    # ─── Command handlers ─────────────────────────────────────────────────

    async def cmd_start(self, update, ctx):
        await self._reply(update, self._help_text())

    async def cmd_help(self, update, ctx):
        await self._reply(update, self._help_text())

    async def cmd_status(self, update, ctx):
        if not self.tracker:
            await self._reply(update, "Tracker not running.")
            return

        last = "never"
        if self.tracker.last_scan_time:
            last = time.strftime("%H:%M:%S", time.localtime(self.tracker.last_scan_time))

        masscan_state = "ON 🟢" if self.tracker.masscan_enabled else "OFF 🔴"
        targets = self.tracker.get_targets()
        target_names = ", ".join(t["username"] for t in targets) if targets else "(none)"

        text = (
            f"📊 **Tracker Status**\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"🎯 Targets: {len(targets)} ({target_names})\n"
            f"📡 Masscan: {masscan_state}\n"
            f"🕐 Last scan: {last}\n"
            f"🌐 Scanned: {self.tracker.last_scanned}\n"
            f"✅ Connectable: {self.tracker.last_connectable}\n"
            f"🎯 Hits this cycle: {len(self.tracker.last_hits)}\n"
            f"📈 Total hits: {self.tracker.total_hits}\n"
            f"🔄 Total scans: {self.tracker.total_scans}"
        )
        await self._reply(update, text)

    async def cmd_target(self, update, ctx):
        if not ctx.args:
            await self._reply(update, "Usage: `/target <USERNAME>`")
            return
        username = ctx.args[0]
        if not self.tracker:
            await self._reply(update, "Tracker not running.")
            return

        for t in self.tracker.get_targets():
            if t["username"].lower() == username.lower():
                await self._reply(update, f"⚠️ `{username}` is already tracked.\n🆔 `{t['uuid']}`")
                return

        await self._reply(update, f"🔍 Looking up `{username}` on Mojang...")
        result = await fetch_uuid(username)
        if not result or not result.get("uuid"):
            await self._reply(update, f"❌ Player `{username}` not found on Mojang.")
            return

        added = self.tracker.add_target(result["username"], result["uuid"])
        uuid_fmt = result["uuid"]
        if len(uuid_fmt) == 32:
            uuid_fmt = f"{uuid_fmt[:8]}-{uuid_fmt[8:12]}-{uuid_fmt[12:16]}-{uuid_fmt[16:20]}-{uuid_fmt[20:]}"

        if added:
            await self._reply(update, (
                f"✅ Now tracking `{result['username']}`\n"
                f"🆔 UUID: `{uuid_fmt}`\n"
                f"📡 Masscan: {'ON 🟢' if self.tracker.masscan_enabled else 'OFF 🔴'}"
            ))
        else:
            await self._reply(update, f"⚠️ `{username}` is already tracked.")

    async def cmd_untarget(self, update, ctx):
        if not ctx.args:
            await self._reply(update, "Usage: `/untarget <USERNAME>`")
            return
        username = ctx.args[0]
        if not self.tracker:
            await self._reply(update, "Tracker not running.")
            return
        removed = self.tracker.remove_target(username)
        if removed:
            await self._reply(update, f"🗑 Stopped tracking `{username}`.")
        else:
            await self._reply(update, f"❌ `{username}` was not in the watch list.")

    async def cmd_targets(self, update, ctx):
        if not self.tracker:
            await self._reply(update, "Tracker not running.")
            return
        targets = self.tracker.get_targets()
        if not targets:
            await self._reply(update, "🎯 No targets. Use `/target <USERNAME>` to add one.")
            return
        lines = []
        for t in targets:
            uuid_fmt = t["uuid"]
            if len(uuid_fmt) == 32:
                uuid_fmt = f"{uuid_fmt[:8]}-{uuid_fmt[8:12]}-{uuid_fmt[12:16]}-{uuid_fmt[16:20]}-{uuid_fmt[20:]}"
            lines.append(f"  👤 `{t['username']}` — 🆔 `{uuid_fmt}`")
        await self._reply(update, f"🎯 **Watched targets ({len(targets)}):**\n" + "\n".join(lines))

    async def cmd_masscan(self, update, ctx):
        if not self.tracker:
            await self._reply(update, "Tracker not running.")
            return
        if not ctx.args:
            state = "ON 🟢" if self.tracker.masscan_enabled else "OFF 🔴"
            await self._reply(update, f"📡 Masscan: {state}\nUsage: `/masscan on` or `/masscan off`")
            return
        arg = ctx.args[0].lower().strip()
        if arg in ("on", "enable", "start", "1", "true"):
            self.tracker.set_masscan(True)
            await self._reply(update, "📡 Masscan: **ON** 🟢\nScanning IP ranges for MC servers (TCP 25565 + UDP 19132).")
        elif arg in ("off", "disable", "stop", "0", "false"):
            self.tracker.set_masscan(False)
            await self._reply(update, "📡 Masscan: **OFF** 🔴\nUsing manual server list only.")
        else:
            await self._reply(update, "Usage: `/masscan on` or `/masscan off`")

    async def cmd_scan(self, update, ctx):
        if not self.tracker:
            await self._reply(update, "Tracker not running.")
            return
        masscan_state = "ON 🟢" if self.tracker.masscan_enabled else "OFF 🔴 (manual)"
        await self._reply(update, f"🔄 Triggering scan...\n📡 Masscan: {masscan_state}")
        asyncio.create_task(self._do_scan(update))

    async def _do_scan(self, update):
        try:
            hits = await self.tracker.run_cycle()
            if hits:
                await self._reply(update, f"🎯 Found {len(hits)} target(s)!")
                for h in hits:
                    await self._reply(update, h.telegram_text())
            else:
                await self._reply(update, "❌ No targets found this scan.")
        except Exception as e:
            await self._reply(update, f"⚠️ Scan error: {e}")

    async def cmd_servers(self, update, ctx):
        if not self.tracker or not self.tracker.last_hits:
            await self._reply(update, "No recent hits. Use `/scan` first.")
            return
        lines = []
        for h in self.tracker.last_hits:
            proto = "UDP" if h.proto == "udp" else "TCP"
            lines.append(f"  🌐 `{h.host}:{h.port}` ({proto}) — 👤 {h.username}")
        await self._reply(update, f"🌐 **Recent hits ({len(self.tracker.last_hits)}):**\n" + "\n".join(lines))

    async def cmd_plugins(self, update, ctx):
        """Check plugins on a specific server: /plugins <host> [port]"""
        if not ctx.args:
            await self._reply(update, "Usage: `/plugins <host> [port]`\nExample: `/plugins play.hypixel.net 25565`")
            return

        host = ctx.args[0]
        port = int(ctx.args[1]) if len(ctx.args) > 1 else 25565
        is_bedrock = port in BEDROCK_PORTS

        await self._reply(update, f"🔍 Checking plugins on `{host}:{port}`...")

        try:
            # Ping the server
            if is_bedrock:
                slp_data = await ping_bedrock(host, port, timeout=10)
            else:
                slp_data = await ping_server(host, port, timeout=10, protocols=["json", "legacy"])

            if not slp_data:
                await self._reply(update, f"❌ `{host}:{port}` is not connectable.")
                return

            # Query for plugins
            query_data = await query_server(host, port, timeout=10)
            if query_data is None and not is_bedrock:
                query_data = await query_server(host, port + 1, timeout=10)

            # Run plugin check
            report = check_plugins(slp_data=slp_data, query_data=query_data)
            report_text = format_plugin_report(report)

            proto_label = "🟫 Bedrock" if is_bedrock else "🟩 Java"
            text = (
                f"🔌 **Plugin Report**\n"
                f"{proto_label} `{host}:{port}`\n"
                f"📝 MOTD: {slp_data.get('motd', '')[:60]}\n"
                f"👥 Players: {slp_data.get('players_online', 0)}/{slp_data.get('players_max', 0)}\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"{report_text}"
            )
            await self._reply(update, text)

        except Exception as e:
            await self._reply(update, f"⚠️ Plugin check error: {e}")

    # ─── Helpers ──────────────────────────────────────────────────────────

    async def _reply(self, update, text):
        try:
            await update.message.reply_text(text, parse_mode=ParseMode.MARKDOWN)
        except Exception:
            await update.message.reply_text(text)

    def _help_text(self) -> str:
        return (
            "🤖 **Minecraft Bot Tracker** (UUID + multi-protocol)\n\n"
            "Commands:\n"
            "/target <USERNAME> — track player (UUID from Mojang)\n"
            "/untarget <USERNAME> — stop tracking\n"
            "/targets — list watched players + UUIDs\n"
            "/masscan <on|off> — toggle masscan\n"
            "/scan — trigger immediate scan\n"
            "/status — tracker status + scan summary\n"
            "/servers — show recent hits\n"
            "/plugins <host> [port] — check server plugins\n"
            "/help — this message"
        )

    # ─── Lifecycle ────────────────────────────────────────────────────────

    def build(self):
        if not TELEGRAM_BOT_TOKEN or TELEGRAM_BOT_TOKEN.startswith("PUT_YOUR"):
            raise ValueError("Set TELEGRAM_BOT_TOKEN in config.py first!")

        self.app = ApplicationBuilder().token(TELEGRAM_BOT_TOKEN).build()

        self.app.add_handler(CommandHandler("start", self.cmd_start))
        self.app.add_handler(CommandHandler("help", self.cmd_help))
        self.app.add_handler(CommandHandler("status", self.cmd_status))
        self.app.add_handler(CommandHandler("target", self.cmd_target))
        self.app.add_handler(CommandHandler("untarget", self.cmd_untarget))
        self.app.add_handler(CommandHandler("targets", self.cmd_targets))
        self.app.add_handler(CommandHandler("masscan", self.cmd_masscan))
        self.app.add_handler(CommandHandler("scan", self.cmd_scan))
        self.app.add_handler(CommandHandler("servers", self.cmd_servers))
        self.app.add_handler(CommandHandler("plugins", self.cmd_plugins))

        self.notifier = TelegramNotifier(self.app)
        return self.app

    async def start_polling(self):
        if not self.app:
            self.build()
        await self.app.initialize()
        await self.app.start()
        await self.app.updater.start_polling()
        log.info("Telegram bot polling started.")

    async def stop(self):
        if self.app:
            await self.app.updater.stop()
            await self.app.stop()
            await self.app.shutdown()
            log.info("Telegram bot stopped.")