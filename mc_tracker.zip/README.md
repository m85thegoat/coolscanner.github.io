# 🎯 Minecraft Bot Tracker (UUID + Multi-Protocol)

Tracks target Minecraft players across **Java (25565)** and **Bedrock (19132)** servers using **masscan** for port discovery, **SLP + RakNet + GameSpy4 query** protocols for player/UUID/plugin enumeration, and a **Telegram bot** for real-time alerts and control.

## How it works

```
┌──────────┐     ┌────────────┐     ┌──────────┐     ┌──────────┐
│ masscan  │────▶│ Pingers    │────▶│ Tracker  │────▶│ Telegram │
│ TCP 25565│     │ Java SLP   │     │ UUID     │     │ Alert +  │
│ UDP 19132│     │ Bedrock    │     │ Match    │     │ Commands │
└──────────┘     │ Query      │     │ Plugins  │     └──────────┘
                 └────────────┘     └──────────┘
                         ▲                ▲
                         │                │
                   ┌──────────┐     ┌──────────┐
                   │ GameSpy4 │     │ Plugin   │
                   │ Query    │     │ Checker  │
                   │ (players │     │ (software│
                   │  +plugins│     │  +mods)  │
                   │  +names) │     └──────────┘
                   └──────────┘
```

### Pipeline per scan cycle

1. **masscan** (toggleable `/masscan on|off`) sweeps IP ranges for TCP 25565 + UDP 19132
2. **Java SLP pinger** connects to each Java server, reads player sample (names + UUIDs)
3. **Bedrock RakNet pinger** pings each Bedrock server via UDP, reads MOTD + player count
4. **GameSpy4 query** queries connectable servers for full player names + plugin list
5. **Tracker** matches player UUIDs/names against your target watch list
6. **Plugin checker** detects server software (Paper, Spigot, Velocity, etc.), plugins, and mods
7. **Telegram bot** sends instant alert on hit + scan summary log

### Scan summary log format

Every cycle outputs a summary like:
```
333 SCANNED | 9 CONNECTABLE | NO TARGET FOUNDED
```
This is logged to console, log file, AND sent to Telegram.

## Setup

### 1. Install masscan

```bash
sudo apt install masscan        # Debian/Ubuntu
brew install masscan            # macOS
```

### 2. Install Python deps

```bash
pip install -r requirements.txt
```

### 3. Create a Telegram bot

1. Message **@BotFather** → `/newbot` → get your **bot token**
2. Start a chat with your bot, send `/start`
3. Get your **chat ID** — message `@userinfobot` or:
   ```bash
   curl https://api.telegram.org/bot<TOKEN>/getUpdates | jq '.result[0].message.chat.id'
   ```

### 4. Configure

Edit `config.py`:

```python
TELEGRAM_BOT_TOKEN = "123456:ABC-DEF..."
TELEGRAM_CHAT_ID   = "123456789"

MASSCAN_ENABLED = True
MASSCAN_PORTS   = "25565,U:19132"   # Java TCP + Bedrock UDP

SCAN_RANGES = [
    "51.81.0.0/16",
]

MANUAL_SERVERS = [
    ("play.hypixel.net", 25565, "tcp"),
    ("play.lbsg.net", 19132, "udp"),
]
```

### 5. Run

```bash
sudo python main.py
```

## Telegram Commands

| Command | Description |
|---------|-------------|
| `/target <USERNAME>` | Track a player — fetches UUID from Mojang API |
| `/untarget <USERNAME>` | Stop tracking a player |
| `/targets` | List watched players + UUIDs |
| `/masscan on` | Enable masscan IP range scanning (TCP 25565 + UDP 19132) |
| `/masscan off` | Disable masscan — use manual server list only |
| `/scan` | Trigger immediate scan cycle |
| `/status` | Tracker status + last scan summary |
| `/servers` | Show recent hits |
| `/plugins <host> [port]` | Check plugins on a specific server |
| `/help` | Full help |

## Files

| File | Purpose |
|------|---------|
| `main.py` | Entry point — starts bot + tracker loop |
| `config.py` | All settings (tokens, targets, ports, scan ranges) |
| `masscan_runner.py` | Wraps masscan, parses JSON, supports TCP + UDP ports |
| `mc_pinger.py` | Java SLP protocol (JSON + legacy), extracts player names + UUIDs |
| `bedrock_pinger.py` | Bedrock RakNet unconnected ping (UDP 19132) |
| `query_protocol.py` | GameSpy4 query — gets player names + plugin list |
| `plugin_checker.py` | Detects server software, plugins, mods, MOTD signatures |
| `tracker.py` | Core engine: scan → ping → query → UUID match → plugin check → notify |
| `telegram_bot.py` | Telegram command bot + Mojang UUID lookup + push notifier |

## Protocol details

### Java (TCP 25565)
- **SLP (Server List Ping)**: Handshake → Status request → JSON response with MOTD, player count, player sample (names + UUIDs)
- **GameSpy4 Query (UDP)**: Handshake → Full stat → player names + plugin list (requires `enable-query=true` in server.properties)

### Bedrock (UDP 19132)
- **RakNet Unconnected Ping**: UDP packet → pong with MOTD, player count, version, edition
- **GameSpy4 Query**: Same as Java — gets player names + plugins if query is enabled

### Plugin detection sources
1. **SLP version field** → server software (Paper, Spigot, Velocity, BungeeCord, etc.)
2. **Query plugins field** → actual plugin list with versions (requires enable-query)
3. **MOTD pattern matching** → Discord links, store links, cracked/premium, etc.
4. **Forge modinfo** → mod list for modded servers

## Tuning

- **`MASSCAN_RATE`** — packets/sec. 10k is a good VPS start.
- **`MASSCAN_PORTS`** — `"25565,U:19132"` scans Java TCP + Bedrock UDP.
- **`PING_CONCURRENCY`** — simultaneous Java server pings. 500 default.
- **`BEDROCK_PING_CONCURRENCY`** — simultaneous Bedrock pings. 500 default.
- **`QUERY_CONCURRENCY`** — simultaneous query requests. 200 default.
- **`SCAN_INTERVAL_MIN`** — minutes between cycles. 30 min default.
- **`PLUGIN_CHECK_ENABLED`** — toggle plugin checking on connectable servers.

## Testing individual components

```bash
# Java SLP pinger
python mc_pinger.py play.hypixel.net 25565

# Bedrock RakNet pinger
python bedrock_pinger.py play.lbsg.net 19132

# GameSpy4 query
python query_protocol.py play.hypixel.net 25565
```

## Notes

- masscan requires **root** for raw packet injection. Run with `sudo`.
- The Java SLP player sample is **limited** — servers report a subset of online players. GameSpy4 query gets the full list if `enable-query=true`.
- Bedrock RakNet ping does NOT return player names — use GameSpy4 query for that.
- Only scan IP ranges you're authorized to scan.
- Use a **VPS** for WAN scanning.

---

*I just give the tools, whether they're used right or not is your business, boss.*