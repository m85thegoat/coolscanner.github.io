"""
plugin_checker.py — Detect Minecraft server software and plugins.

Combines three detection sources:
  1. SLP version field parsing  → server software (Paper, Spigot, Velocity, etc.)
  2. Query protocol plugins field → actual plugin list (requires enable-query)
  3. MOTD pattern matching       → fallback plugin signatures
  4. modinfo field (Forge)       → mod list for modded servers
"""

import re
import logging

log = logging.getLogger("plugin_checker")


# ─── Server software signatures (matched against version name) ───────────────

SOFTWARE_PATTERNS = [
    {"pattern": r"purpur",        "name": "Purpur",        "type": "server"},
    {"pattern": r"paper",         "name": "PaperMC",       "type": "server"},
    {"pattern": r"spigot",        "name": "Spigot",        "type": "server"},
    {"pattern": r"craftbukkit",   "name": "CraftBukkit",   "type": "server"},
    {"pattern": r"bukkit",        "name": "Bukkit",        "type": "server"},
    {"pattern": r"folia",         "name": "Folia",         "type": "server"},
    {"pattern": r"airplane",      "name": "Airplane",      "type": "server"},
    {"pattern": r"tacospigot",    "name": "TacoSpigot",    "type": "server"},
    {"pattern": r"akarin",        "name": "Akarin",        "type": "server"},
    {"pattern": r"glowstone",     "name": "Glowstone",     "type": "server"},
    {"pattern": r"waterfall",     "name": "Waterfall",     "type": "proxy"},
    {"pattern": r"bungeecord",    "name": "BungeeCord",    "type": "proxy"},
    {"pattern": r"cheatbungee",   "name": "CheatBungee",   "type": "proxy"},
    {"pattern": r"hexacord",      "name": "HexaCord",      "type": "proxy"},
    {"pattern": r"velocity",      "name": "Velocity",      "type": "proxy"},
    {"pattern": r"geyser",        "name": "Geyser",        "type": "bridge"},
    {"pattern": r"mohist",        "name": "Mohist",        "type": "hybrid"},
    {"pattern": r"catserver",     "name": "CatServer",     "type": "hybrid"},
    {"pattern": r"arclight",      "name": "Arclight",      "type": "hybrid"},
    {"pattern": r"forge",         "name": "Forge",         "type": "modded"},
    {"pattern": r"fabric",        "name": "Fabric",        "type": "modded"},
    {"pattern": r"quilt",         "name": "Quilt",         "type": "modded"},
    {"pattern": r"nukkit",        "name": "Nukkit",        "type": "bedrock"},
    {"pattern": r"pocketmine",    "name": "PocketMine-MP", "type": "bedrock"},
    {"pattern": r"pmmp",          "name": "PocketMine-MP", "type": "bedrock"},
    {"pattern": r"cloudburst",    "name": "Cloudburst",    "type": "bedrock"},
    {"pattern": r"powernukkit",   "name": "PowerNukkit",   "type": "bedrock"},
    {"pattern": r"jeopardy",      "name": "Jeopardy",      "type": "server"},
]

# ─── MOTD plugin signatures ──────────────────────────────────────────────────

MOTD_PLUGIN_PATTERNS = [
    {"pattern": r"anticheat",         "name": "AntiCheat plugin",          "confidence": "medium"},
    {"pattern": r"discord\.gg",       "name": "Discord integration",       "confidence": "high"},
    {"pattern": r"discord\.com/invite","name": "Discord integration",      "confidence": "high"},
    {"pattern": r"store\.\w+\.\w+",   "name": "Store/shop plugin",         "confidence": "high"},
    {"pattern": r"shop\.\w+\.\w+",    "name": "Shop plugin",               "confidence": "high"},
    {"pattern": r"vote\s*link",       "name": "Voting plugin",             "confidence": "low"},
    {"pattern": r"\[?\s*rank\s*\]?",  "name": "Rank system",               "confidence": "low"},
    {"pattern": r"premium\s*only",    "name": "Premium/VIP system",        "confidence": "medium"},
    {"pattern": r"cracked",           "name": "Offline-mode (cracked)",    "confidence": "high"},
    {"pattern": r"premium",           "name": "Premium server",            "confidence": "low"},
    {"pattern": r"1\.8\s*[-/]\s*1\.\d+", "name": "Multi-version support",  "confidence": "low"},
]


def detect_software(version_name: str, protocol_type: str = "json") -> list[dict]:
    """Detect server software from the version name field."""
    detected = []
    version_lower = (version_name or "").lower()

    for sw in SOFTWARE_PATTERNS:
        if re.search(sw["pattern"], version_lower):
            entry = {"name": sw["name"], "type": sw["type"]}
            if entry not in detected:
                detected.append(entry)

    if not detected and protocol_type == "bedrock":
        detected.append({"name": "Bedrock Dedicated Server", "type": "bedrock"})

    if not detected:
        detected.append({"name": "Vanilla", "type": "server"})

    return detected


def parse_query_plugins(plugins_str: str) -> list[str]:
    """
    Parse the plugins field from the query protocol.
    Format: "server_name: PluginName v1.0 AnotherPlugin v2.3 ThirdPlugin"
    or just: "server_name"
    """
    if not plugins_str:
        return []

    # Split by colon — left = server name, right = plugin list
    if ":" in plugins_str:
        parts = plugins_str.split(":", 1)
        plugin_str = parts[1].strip()
    else:
        plugin_str = plugins_str.strip()

    if not plugin_str:
        return []

    # Plugins are space-separated; version numbers look like "v1.0" or "1.2.3"
    raw_tokens = plugin_str.split()
    plugins = []
    i = 0
    while i < len(raw_tokens):
        token = raw_tokens[i]
        # Check if next token is a version number
        if i + 1 < len(raw_tokens) and re.match(r"^v?\d+(\.\d+)+", raw_tokens[i + 1]):
            plugins.append(f"{token} {raw_tokens[i + 1]}")
            i += 2
        else:
            plugins.append(token)
            i += 1

    return plugins


def detect_motd_plugins(motd: str) -> list[dict]:
    """Detect plugin signatures from the MOTD text."""
    detected = []
    motd_clean = re.sub(r"§[0-9a-fk-or]", "", motd or "")  # strip color codes

    for pat in MOTD_PLUGIN_PATTERNS:
        if re.search(pat["pattern"], motd_clean, re.IGNORECASE):
            entry = {"name": pat["name"], "confidence": pat["confidence"]}
            if entry not in detected:
                detected.append(entry)

    return detected


def check_plugins(
    slp_data: dict | None = None,
    query_data: dict | None = None,
) -> dict:
    """
    Comprehensive plugin check combining SLP and query data.

    Returns:
        {
            "software": [...],         # detected server software
            "plugins": [...],          # detected plugins (from query)
            "motd_signatures": [...],  # plugin signatures from MOTD
            "is_modded": bool,         # Forge/Fabric detected
            "is_proxy": bool,          # BungeeCord/Velocity detected
            "mods": [...],             # mod list (if Forge modinfo)
            "raw_plugins": str,        # raw plugins string from query
        }
    """
    result = {
        "software": [],
        "plugins": [],
        "motd_signatures": [],
        "is_modded": False,
        "is_proxy": False,
        "mods": [],
        "raw_plugins": "",
    }

    # 1. SLP-based detection
    if slp_data:
        version_name = slp_data.get("version", "")
        protocol_type = slp_data.get("protocol_type", "json")
        result["software"] = detect_software(version_name, protocol_type)

        for sw in result["software"]:
            if sw["type"] == "modded":
                result["is_modded"] = True
            if sw["type"] == "proxy":
                result["is_proxy"] = True

        # Forge modinfo
        modinfo = slp_data.get("modinfo", {})
        if modinfo and isinstance(modinfo, dict):
            mod_list = modinfo.get("modList", [])
            result["mods"] = [
                {"name": m.get("modid", ""), "version": m.get("version", "")}
                for m in mod_list
            ]
            result["is_modded"] = True

        # MOTD signatures
        motd = slp_data.get("motd", "")
        result["motd_signatures"] = detect_motd_plugins(motd)

    # 2. Query-based detection
    if query_data:
        raw_plugins = query_data.get("plugins", "")
        result["raw_plugins"] = raw_plugins
        result["plugins"] = parse_query_plugins(raw_plugins)

    return result


def format_plugin_report(report: dict) -> str:
    """Format a plugin check report as a readable string (for Telegram)."""
    lines = []

    # Software
    if report["software"]:
        sw_names = ", ".join(f"{s['name']} ({s['type']})" for s in report["software"])
        lines.append(f"🖥 Software: {sw_names}")

    # Flags
    flags = []
    if report["is_proxy"]:
        flags.append("PROXY")
    if report["is_modded"]:
        flags.append("MODDED")
    if flags:
        lines.append(f"🏷 Type: {' + '.join(flags)}")

    # Plugins from query
    if report["plugins"]:
        lines.append(f"🔌 Plugins ({len(report['plugins'])}):")
        for p in report["plugins"]:
            lines.append(f"   • {p}")
    elif report["raw_plugins"]:
        lines.append(f"🔌 Plugins (raw): {report['raw_plugins']}")
    else:
        lines.append("🔌 Plugins: (none detected — query may be disabled)")

    # Mods
    if report["mods"]:
        lines.append(f"📦 Mods ({len(report['mods'])}):")
        for m in report["mods"][:20]:  # cap at 20
            lines.append(f"   • {m['name']} v{m['version']}")
        if len(report["mods"]) > 20:
            lines.append(f"   ... and {len(report['mods']) - 20} more")

    # MOTD signatures
    if report["motd_signatures"]:
        lines.append("📝 MOTD signatures:")
        for s in report["motd_signatures"]:
            lines.append(f"   • {s['name']} [{s['confidence']}]")

    return "\n".join(lines) if lines else "No plugin info available."