"""
mc_pinger.py — Minecraft Server List Ping (SLP) implementation.

Supports two protocol flavours:
  1. JSON  (Minecraft 1.7+  — modern servers)
  2. Legacy (Minecraft 1.6 / Beta 1.8 — older servers)

Returns a dict with server info including the player sample (list of online
player names).  All I/O is async via asyncio streams.
"""

import asyncio
import json
import struct
import logging

log = logging.getLogger("mc_pinger")


# ─── helpers ─────────────────────────────────────────────────────────────────

async def _read_varint_async(reader: asyncio.StreamReader) -> int:
    """Read a Minecraft VarInt from the stream."""
    value = 0
    for i in range(5):
        data = await reader.readexactly(1)
        byte = data[0]
        value |= (byte & 0x7F) << (7 * i)
        if not (byte & 0x80):
            return value
    raise ValueError("VarInt too big")


async def _read_string(reader: asyncio.StreamReader) -> str:
    length = await _read_varint_async(reader)
    data = await reader.readexactly(length)
    return data.decode("utf-8")


# ─── JSON protocol (1.7+) ────────────────────────────────────────────────────

async def ping_json(host: str, port: int, timeout: float) -> dict | None:
    """
    Perform a modern Server List Ping (protocol 47+ / 1.7+).
    Returns dict with keys: motd, players_online, players_max, players (list of names), version, ping_ms
    """
    try:
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(host, port), timeout=timeout
        )
    except (asyncio.TimeoutError, ConnectionRefusedError, OSError):
        return None

    try:
        # ── Build handshake payload ───────────────────────────────────────
        payload = _build_handshake(host, port)
        writer.write(_frame_packet(payload))
        await writer.drain()

        # ── Status request (empty payload, packet id 0x00) ───────────────
        writer.write(_frame_packet(b"\x00"))
        await writer.drain()

        # ── Read response ────────────────────────────────────────────────
        import time
        t0 = time.monotonic()
        packet_len = await _read_varint_async(reader)
        packet_id = await _read_varint_async(reader)
        if packet_id != 0x00:
            return None
        json_str = await _read_string(reader)
        ping_ms = int((time.monotonic() - t0) * 1000)

        data = json.loads(json_str)

        players = []
        sample = data.get("players", {}).get("sample", [])
        if sample:
            # Each sample entry has "name" and "id" (UUID without dashes)
            players = [
                {"name": p.get("name", ""), "uuid": p.get("id", "")}
                for p in sample if p.get("name")
            ]

        return {
            "host": host,
            "port": port,
            "motd": _extract_motd(data.get("description", "")),
            "players_online": data.get("players", {}).get("online", 0),
            "players_max": data.get("players", {}).get("max", 0),
            "players": players,
            "version": data.get("version", {}).get("name", "unknown"),
            "protocol": data.get("version", {}).get("protocol", -1),
            "ping_ms": ping_ms,
            "protocol_type": "json",
            "modinfo": data.get("modinfo", {}),
            "favicon": bool(data.get("favicon", "")),
        }

    except (asyncio.TimeoutError, asyncio.IncompleteReadError, json.JSONDecodeError, OSError, ValueError):
        return None
    finally:
        try:
            writer.close()
        except Exception:
            pass


def _build_handshake(host: str, port: int) -> bytes:
    """Build the handshake packet payload (without length prefix)."""
    buf = bytearray()
    buf.append(0x00)  # packet id
    # protocol version = -1 as VarInt
    buf += _encode_varint(-1)
    # server address string
    host_bytes = host.encode("utf-8")
    buf += _encode_varint(len(host_bytes))
    buf += host_bytes
    # port (unsigned short, big-endian)
    buf += struct.pack(">H", port)
    # next state = 1 (status)
    buf += _encode_varint(1)
    return bytes(buf)


def _encode_varint(value: int) -> bytes:
    """Encode an int as a Minecraft VarInt."""
    buf = bytearray()
    remaining = value & 0xFFFFFFFF  # treat as unsigned for -1 etc.
    while True:
        byte = remaining & 0x7F
        remaining >>= 7
        if remaining == 0 and not (byte & 0x40 and value < 0):
            buf.append(byte)
            break
        buf.append(byte | 0x80)
    return bytes(buf)


def _frame_packet(payload: bytes) -> bytes:
    """Prefix a packet payload with its length as a VarInt."""
    return _encode_varint(len(payload)) + payload


def _extract_motd(description) -> str:
    """Extract plain-text MOTD from the description field (str or dict)."""
    if isinstance(description, str):
        return description
    if isinstance(description, dict):
        text = description.get("text", "")
        extra = description.get("extra", [])
        for e in extra:
            if isinstance(e, dict):
                text += e.get("text", "")
            elif isinstance(e, str):
                text += e
        return text
    return str(description)


# ─── Legacy protocol (1.6 / Beta) ────────────────────────────────────────────

async def ping_legacy(host: str, port: int, timeout: float) -> dict | None:
    """
    Legacy server list ping (§1 + ping token).
    Works for Minecraft 1.4.x–1.6.x and some Beta servers.
    """
    try:
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(host, port), timeout=timeout
        )
    except (asyncio.TimeoutError, ConnectionRefusedError, OSError):
        return None

    try:
        import time
        t0 = time.monotonic()
        # Legacy ping packet:
        #   FE 01            (legacy ping magic)
        #   FA               (packet identifier)
        #   00 0B            (string length = 11)
        #   "MC|PingHost"    (UTF-16BE)
        #   49 00            (protocol version = 73)
        #   string length    (UTF-16BE, of host:port)
        #   host:port        (UTF-16BE)
        host_port_str = f"{host}:{port}"
        host_port_utf16 = host_port_str.encode("utf-16-be")
        payload = bytearray()
        payload += b"\xfe\x01"
        payload += b"\xfa"
        payload += struct.pack(">H", 11)
        payload += "MC|PingHost".encode("utf-16-be")
        payload += struct.pack(">H", 1 + 2 + len(host_port_utf16))  # remaining length
        payload += b"\x49"  # protocol 73
        payload += struct.pack(">H", len(host_port_utf16))
        payload += host_port_utf16

        writer.write(bytes(payload))
        await writer.drain()

        # Read response — starts with 0xFF
        first = await reader.readexactly(1)
        if first != b"\xff":
            return None

        # Read the rest (length-prefixed UTF-16BE string)
        length_bytes = await reader.readexactly(2)
        str_len = struct.unpack(">H", length_bytes)[0]
        raw = await reader.readexactly(str_len * 2)
        text = raw.decode("utf-16-be", errors="replace")
        ping_ms = int((time.monotonic() - t0) * 1000)

        # Parse: §1\x00protocol\x00version\x00motd\x00online\x00max
        if text.startswith("\xa7\x01\x00") or text.startswith("\u00a71\x00"):
            parts = text.split("\x00")
            if len(parts) >= 6:
                return {
                    "host": host,
                    "port": port,
                    "motd": parts[2],
                    "players_online": int(parts[3]) if parts[3].isdigit() else 0,
                    "players_max": int(parts[4]) if parts[4].isdigit() else 0,
                    "players": [],  # legacy doesn't return player sample
                    "version": parts[1],
                    "protocol": int(parts[0].replace("\xa7", "").replace("1", "")) if parts[0] else -1,
                    "ping_ms": ping_ms,
                    "protocol_type": "legacy",
                }
        # Even older: motd\x00online\x00max
        else:
            parts = text.split("\xa7")  # § separator for very old servers
            if len(parts) >= 3:
                return {
                    "host": host,
                    "port": port,
                    "motd": parts[0],
                    "players_online": int(parts[1]) if parts[1].isdigit() else 0,
                    "players_max": int(parts[2]) if parts[2].isdigit() else 0,
                    "players": [],
                    "version": "legacy",
                    "protocol": -1,
                    "ping_ms": ping_ms,
                    "protocol_type": "legacy",
                }
        return None

    except (asyncio.TimeoutError, asyncio.IncompleteReadError, OSError, ValueError, UnicodeDecodeError):
        return None
    finally:
        try:
            writer.close()
        except Exception:
            pass


# ─── Public API ──────────────────────────────────────────────────────────────

async def ping_server(host: str, port: int, timeout: float = 5.0, protocols: list[str] | None = None) -> dict | None:
    """
    Ping a Minecraft server and return its status dict, or None if unreachable.
    Tries JSON protocol first, then legacy.
    """
    if protocols is None:
        protocols = ["json", "legacy"]

    for proto in protocols:
        if proto == "json":
            result = await ping_json(host, port, timeout)
        elif proto == "legacy":
            result = await ping_legacy(host, port, timeout)
        else:
            continue
        if result:
            return result
    return None


async def ping_many(servers: list[tuple[str, int]], timeout: float = 5.0,
                    concurrency: int = 500, protocols: list[str] | None = None) -> list[dict]:
    """
    Ping many servers concurrently.  Returns list of result dicts (only reachable ones).
    """
    sem = asyncio.Semaphore(concurrency)

    async def _wrapped(host, port):
        async with sem:
            return await ping_server(host, port, timeout, protocols)

    tasks = [_wrapped(h, p) for h, p in servers]
    results = await asyncio.gather(*tasks, return_exceptions=True)
    return [r for r in results if isinstance(r, dict)]


# ─── quick self-test ─────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys
    test_host = sys.argv[1] if len(sys.argv) > 1 else "play.hypixel.net"
    test_port = int(sys.argv[2]) if len(sys.argv) > 2 else 25565
    result = asyncio.run(ping_server(test_host, test_port, timeout=10))
    if result:
        print(json.dumps(result, indent=2))
    else:
        print(f"No response from {test_host}:{test_port}")