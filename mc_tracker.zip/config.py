"""
config.py — Central configuration for the Minecraft Bot Tracker.
Edit the values below before running.
"""

# ─── Telegram ────────────────────────────────────────────────────────────────
TELEGRAM_BOT_TOKEN = "PUT_YOUR_TELEGRAM_BOT_TOKEN_HERE"
TELEGRAM_CHAT_ID   = "PUT_YOUR_TELEGRAM_CHAT_ID_HERE"

# ─── Target players (UUID-based) ─────────────────────────────────────────────
# Added at runtime via /target <USERNAME> (fetches UUID from Mojang).
# Pre-seed here too: {"username": "...", "uuid": "..."}
TARGETS = [
    # {"username": "Notch", "uuid": "069a79f444e94726a5befca90e38aaf5"},
]

# ─── Ports ───────────────────────────────────────────────────────────────────
JAVA_PORTS    = {25565, 25566, 25567, 25568, 25569, 25570}
BEDROCK_PORTS = {19132, 19133, 19134, 19135}

# ─── Masscan settings ────────────────────────────────────────────────────────
MASSCAN_BINARY     = "masscan"
MASSCAN_RATE       = 10000
# Scan both Java (TCP 25565) and Bedrock (UDP 19132)
MASSCAN_PORTS      = "25565,U:19132"
MASSCAN_ENABLED    = True
SCAN_RANGES = [
    # "0.0.0.0/0",
    # "192.168.1.0/24",
    # "51.81.0.0/16",
]
MASSCAN_EXCLUDE_FILE = ""
MASSCAN_RETRIES      = 2

# ─── Manual server list (used when masscan is OFF) ───────────────────────────
# Format: (host, port, proto)  — proto is "tcp" or "udp"
# If proto omitted, auto-detected from port number.
MANUAL_SERVERS = [
    # ("play.hypixel.net", 25565, "tcp"),
    # ("play.lbsg.net", 19132, "udp"),
]

# ─── MC Pinger settings ──────────────────────────────────────────────────────
PING_TIMEOUT        = 5
PING_CONCURRENCY    = 500
PING_PROTOCOLS      = ["json", "legacy"]

# ─── Bedrock pinger settings ─────────────────────────────────────────────────
BEDROCK_PING_TIMEOUT     = 5
BEDROCK_PING_CONCURRENCY = 500

# ─── Query protocol settings ─────────────────────────────────────────────────
# GameSpy4 query gets player names + plugins. Tries query on same port,
# then port+1 if the first attempt fails.
QUERY_ENABLED       = True
QUERY_TIMEOUT       = 5
QUERY_CONCURRENCY   = 200

# ─── Mojang API ──────────────────────────────────────────────────────────────
MOJANG_API_URL      = "https://api.mojang.com/users/profiles/minecraft/{username}"
MOJANG_TIMEOUT      = 10

# ─── Tracker loop ────────────────────────────────────────────────────────────
SCAN_INTERVAL_MIN   = 30
SEEN_CACHE_TTL_SEC  = 600

# ─── Plugin checker ──────────────────────────────────────────────────────────
PLUGIN_CHECK_ENABLED = True   # run plugin check on connectable servers

# ─── Output ──────────────────────────────────────────────────────────────────
LOG_FILE            = "tracker.log"
LOG_LEVEL           = "INFO"