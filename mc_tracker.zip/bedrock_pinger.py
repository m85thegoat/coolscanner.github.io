"""
bedrock_pinger.py — Minecraft Bedrock Edition server pinger.

Uses the RakNet Unconnected Ping protocol over UDP to query Bedrock servers
(default port 19132). Returns server info: MOTD, player count, version, etc.

NOTE: The RakNet ping does NOT return individual player names.
      Use query_protocol.py (GameSpy4 query) to get player names for Bedrock.
"""

import asyncio
import struct
import time
import logging

log = logging.getLogger("bedrock_pinger")

# RakNet magic bytes (fixed constant in the protocol)
RAKNET_MAGIC = bytes([
    0x00, 0xFF, 0xFF, 0x00,
    0xFE, 0xFE, 0xFE, 0xFE,
    0xFD, 0xFD, 0xFD, 0xFD,
    0x12, 0x34, 0x56, 0x78,
])


def _build_unconnected_ping() -> bytes:
    """Build a RakNet ID_UNCONNECTED_PING packet."""
    pkt = bytearray()
    pkt.append(0x01)                                  # packet ID
    pkt += struct.pack(">Q", int(time.time() * 1000)) # timestamp (ms, uint64 BE)
    pkt += RAKNET_MAGIC                               # 16-byte magic
    pkt += struct.pack(">q", 0x0102030405060708)      # client GUID (int64 BE)
    return bytes(pkt)


def _parse_unconnected_pong(data: bytes, host: str, port: int) -> dict | None:
    """Parse a RakNet ID_UNCONNECTED_PONG response."""
    if len(data) < 35:
        return None

    offset = 0
    if data[offset] != 0x1C:          # ID_UNCONNECTED_PONG
        return None
    offset += 1
    offset += 8                        # timestamp
    offset += 8                        # server GUID
    offset += 16                       # magic

    if offset + 2 > len(data):
        return None
    str_len = struct.unpack(">H", data[offset:offset + 2])[0]
    offset += 2

    if offset + str_len > len(data):
        return None
    server_id_str = data[offset:offset + str_len].decode("utf-8", errors="replace")

    # Format: MCPE;motd;protocol;version;online;max;server_id;level;game_mode;
    parts = server_id_str.split(";")

    return {
        "host": host,
        "port": port,
        "motd": parts[1] if len(parts) > 1 else "",
        "players_online": int(parts[4]) if len(parts) > 4 and parts[4].lstrip("-").isdigit() else 0,
        "players_max": int(parts[5]) if len(parts) > 5 and parts[5].lstrip("-").isdigit() else 0,
        "players": [],                 # RakNet ping doesn't include player names
        "version": parts[3] if len(parts) > 3 else "unknown",
        "protocol": parts[2] if len(parts) > 2 else "",
        "ping_ms": 0,                  # set by caller
        "protocol_type": "bedrock",
        "edition": parts[0] if len(parts) > 0 else "",
        "level_name": parts[7] if len(parts) > 7 else "",
        "game_mode": parts[8] if len(parts) > 8 else "",
    }


class _BedrockProtocol(asyncio.DatagramProtocol):
    def __init__(self):
        self.fut = asyncio.get_running_loop().create_future()

    def connection_made(self, transport):
        self.transport = transport

    def datagram_received(self, data, addr):
        if not self.fut.done():
            self.fut.set_result(data)

    def error_received(self, exc):
        if not self.fut.done():
            self.fut.set_exception(exc)


async def ping_bedrock(host: str, port: int, timeout: float = 5.0) -> dict | None:
    """Ping a Bedrock server via RakNet unconnected ping (UDP)."""
    loop = asyncio.get_running_loop()

    try:
        transport, protocol = await loop.create_datagram_endpoint(
            lambda: _BedrockProtocol(),
            remote_addr=(host, port),
        )
    except OSError:
        return None

    try:
        t0 = time.monotonic()
        transport.sendto(_build_unconnected_ping())

        data = await asyncio.wait_for(protocol.fut, timeout)
        ping_ms = int((time.monotonic() - t0) * 1000)

        result = _parse_unconnected_pong(data, host, port)
        if result:
            result["ping_ms"] = ping_ms
        return result

    except (asyncio.TimeoutError, OSError):
        return None
    finally:
        transport.close()


async def ping_bedrock_many(
    servers: list[tuple[str, int]],
    timeout: float = 5.0,
    concurrency: int = 500,
) -> list[dict]:
    """Ping many Bedrock servers concurrently. Returns only reachable ones."""
    sem = asyncio.Semaphore(concurrency)

    async def _wrapped(h, p):
        async with sem:
            return await ping_bedrock(h, p, timeout)

    tasks = [_wrapped(h, p) for h, p in servers]
    results = await asyncio.gather(*tasks, return_exceptions=True)
    return [r for r in results if isinstance(r, dict)]


# ─── self-test ────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys, json
    h = sys.argv[1] if len(sys.argv) > 1 else "play.lbsg.net"
    p = int(sys.argv[2]) if len(sys.argv) > 2 else 19132
    r = asyncio.run(ping_bedrock(h, p, timeout=10))
    print(json.dumps(r, indent=2) if r else f"No response from {h}:{p}")